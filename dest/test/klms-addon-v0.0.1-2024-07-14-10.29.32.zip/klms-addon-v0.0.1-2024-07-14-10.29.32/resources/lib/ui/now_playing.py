import xbmc
import xbmcgui
from resources.lib.api.fetch_now_playing import get_now_playing
from resources.lib.api.log_now_playing import log_now_playing
from resources.lib.utils.log_message import log_message


WINDOW = "NowPlaying"
TRACK_TITLE_POS_X = "TrackTitlePosX"

class NowPlaying(xbmcgui.WindowXML):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def onInit(self):
        """
        Called when the window is initialized.
        Fetches and displays 'now playing' information.
        """
        self.set_xml();

    def set_xml(self):
        WINDOW_ID = xbmcgui.getCurrentWindowId()
        VW = xbmcgui.getScreenWidth()
        VH = xbmcgui.getScreenHeight()
        VW_1 = round(VW * 0.001)
        VH_1 = round(VH * 0.001)
        
        self.meta = self.getControl(999);
        self.meta.setLabel(f"{WINDOW_ID}");
        
        self.track_title = self.getControl(1);
        self.track_title.setPosition(500, 500)
        self.track_title.setVisible(True)

        log_message(f"{VW} x {VH} ({VW / 2} x {VH / 2}) ({VW_1} x {VH_1})")
        
    def set_now_playing(self):
        now_playing = get_now_playing()
        if now_playing:
            log_now_playing(now_playing)
        else:
            log_message("No 'now playing' information available.", xbmc.LOGWARNING)
    
    def onClick(self, controlId):
        pass

    def onAction(self, action):
        # This method is called when an action is performed
        if action == xbmcgui.ACTION_PREVIOUS_MENU or action == xbmcgui.ACTION_NAV_BACK:
            self.close()
