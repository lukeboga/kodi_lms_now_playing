import time
import threading
import xbmc
from resources.lib.utils.read_settings import read_settings
from resources.lib.utils.log_message import log_message
from resources.lib.deps import telnetlib
from resources.lib.api.callback_server import CallbackServer  # Import the callback server

# Global telnet connection instance and thread instance
telnet_connection = None
subscriber_thread = None
callback_server = CallbackServer()  # Initialize the callback server

def connect_to_lms():
    """
    Establish a telnet connection to the LMS server using settings from the configuration.

    Returns:
        telnetlib.Telnet: A telnet connection instance.
    """
    global telnet_connection
    settings = read_settings()
    host = settings['lms_server']
    port = settings['lms_telnet_port']
    tn = None

    while tn is None:
        try:
            tn = telnetlib.Telnet(host, port)
            tn.write(b"subscribe playlist\n")  # Subscribe to playlist events
            log_message("Connected to LMS via telnet.")
        except Exception as e:
            log_message(f"Connection failed, retrying in 5 seconds... Error: {e}", xbmc.LOGERROR)
            time.sleep(5)

    telnet_connection = tn
    return tn

def subscribe_to_events(tn):
    """
    Subscribe to events from the LMS server and add them to the callback server.

    Args:
        tn (telnetlib.Telnet): A telnet connection instance.
    """
    while True:
        try:
            response = tn.read_until(b"\n")
            log_message(response)
            callback_server.add_event(response.decode('utf-8'))
        except EOFError:
            log_message("Connection lost, reconnecting...", xbmc.LOGWARNING)
            tn = connect_to_lms()

def start_telnet_subscriber():
    """
    Start a thread to subscribe to LMS events via telnet.
    """
    global subscriber_thread

    # Start the telnet subscription thread
    if subscriber_thread is None or not subscriber_thread.is_alive():
        tn = connect_to_lms()
        subscriber_thread = threading.Thread(target=subscribe_to_events, args=(tn,))
        subscriber_thread.daemon = True
        subscriber_thread.start()

def close_telnet_connection():
    """
    Close the telnet connection and unsubscribe from events.
    """
    global telnet_connection
    if telnet_connection:
        try:
            telnet_connection.write(b"subscribe 0\n")  # Unsubscribe from playlist events
            telnet_connection.close()
            log_message("Telnet connection closed and unsubscribed from events.", xbmc.LOGINFO)
        except Exception as e:
            log_message(f"Error closing telnet connection: {e}", xbmc.LOGERROR)

    # Stop the callback server
    callback_server.stop()

