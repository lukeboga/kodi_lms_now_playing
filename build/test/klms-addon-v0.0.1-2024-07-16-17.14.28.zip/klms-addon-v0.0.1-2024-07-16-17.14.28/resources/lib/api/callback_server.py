import threading
import queue
from resources.lib.utils.log_message import log_message

class CallbackServer:
    def __init__(self, debounce_interval=1.0):
        """
        Initialize the CallbackServer.

        Args:
            debounce_interval (float): The debounce interval in seconds.
        """
        self.subscribers = []
        self.event_queue = queue.Queue()
        self.debounce_interval = debounce_interval
        self.debounce_timer = None
        self.running = True
        self.thread = threading.Thread(target=self.process_events)
        self.thread.daemon = True
        self.thread.start()

    def add_event(self, event_data):
        """
        Add an event to the queue.

        Args:
            event_data (str): The event data to add to the queue.
        """
        self.event_queue.put(event_data)

    def process_events(self):
        """
        Process events from the queue and notify subscribers.
        """
        while self.running:
            try:
                event_data = self.event_queue.get(timeout=1)
                if event_data:
                    self._debounce_event(event_data)
            except queue.Empty:
                continue

    def _debounce_event(self, event_data):
        """
        Debounce the event to ensure only the final event is processed.

        Args:
            event_data (str): The event data to debounce.
        """
        if self.debounce_timer:
            self.debounce_timer.cancel()

        self.debounce_timer = threading.Timer(self.debounce_interval, self._notify_subscribers, args=(event_data,))
        self.debounce_timer.start()

    def _notify_subscribers(self, event_data):
        """
        Notify all subscribers with the event data.

        Args:
            event_data (str): The event data to notify subscribers with.
        """
        for callback in self.subscribers:
            try:
                callback(event_data)
            except Exception as e:
                log_message(f"Error in callback: {e}", level=xbmc.LOGERROR)

    def subscribe(self, callback):
        """
        Subscribe a callback function to be notified of events.

        Args:
            callback (function): The callback function to subscribe.
        """
        self.subscribers.append(callback)

    def stop(self):
        """
        Stop the CallbackServer.
        """
        self.running = False
        if self.debounce_timer:
            self.debounce_timer.cancel()

