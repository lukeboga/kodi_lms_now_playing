class UIElements:
    def __init__(self):
        self.artwork_background = None
        self.artwork = None
        self.now_playing_title = None
        self.now_playing_artist = None
        self.now_playing_album = None
        self.playlist = None

# Instantiate the UIElements class
ui_elements = UIElements()

