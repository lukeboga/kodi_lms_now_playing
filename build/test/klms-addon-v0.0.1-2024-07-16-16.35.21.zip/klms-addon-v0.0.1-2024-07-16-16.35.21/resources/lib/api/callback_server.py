import threading
import queue
from resources.lib.utils.log_message import log_message

class CallbackServer:
    def __init__(self, debounce_interval=1.0):
        """
        Initialize the callback server.

        Args:
            debounce_interval (float): The interval (in seconds) for debouncing events.
        """
        self.subscribers = []
        self.event_queue = queue.Queue()
        self.running = True
        self.debounce_interval = debounce_interval
        self.debounce_timer = None
        self.event_lock = threading.Lock()
        self.thread = threading.Thread(target=self.process_events)
        self.thread.daemon = True
        self.thread.start()

    def subscribe(self, callback):
        """
        Subscribe a new client for updates.

        Args:
            callback (function): The callback function to notify on updates.
        """
        self.subscribers.append(callback)

    def add_event(self, event_data):
        """
        Add a new event to the queue for processing.

        Args:
            event_data (dict): The event data to process.
        """
        with self.event_lock:
            self.event_queue.put(event_data)

    def process_events(self):
        """
        Process events from the queue and notify subscribers.
        """
        while self.running:
            try:
                # Wait for an event with a timeout to allow thread to exit cleanly
                event_data = self.event_queue.get(timeout=1)
                if event_data:
                    self._debounce_event(event_data)
            except queue.Empty:
                continue

    def _debounce_event(self, event_data):
        """
        Debounce the incoming event to prevent excessive updates.

        Args:
            event_data (dict): The event data to process.
        """
        if self.debounce_timer:
            self.debounce_timer.cancel()

        self.debounce_timer = threading.Timer(self.debounce_interval, self._notify_subscribers, args=(event_data,))
        self.debounce_timer.start()

    def _notify_subscribers(self, event_data):
        """
        Notify all subscribers with the event data.

        Args:
            event_data (dict): The event data to send to subscribers.
        """
        for callback in self.subscribers:
            callback(event_data)

    def stop(self):
        """
        Stop the callback server and its processing thread.
        """
        self.running = False
        if self.debounce_timer:
            self.debounce_timer.cancel()
        self.thread.join()
        log_message("Callback server stopped.")

