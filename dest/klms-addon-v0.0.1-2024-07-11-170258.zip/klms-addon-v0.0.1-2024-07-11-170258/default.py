# Import necessary modules from the Kodi API
import xbmc
import xbmcgui
import sys

# Main entry point for the addon
def main():
    """
    The main function serves as the entry point for the addon.
    It loads a simple window displaying 'Hello World' by default.
    """
    show_hello_world()

# Function to show a simple window with 'Hello World' text
def show_hello_world():
    """
    Opens a simple window to display 'Hello World' text.
    """
    xbmc.executebuiltin('Dialog.Close(all, true)')
    window = xbmcgui.Window()
    window.show()
    
    # Create a label control to display 'Hello World'
    label = xbmcgui.ControlLabel(100, 100, 200, 50, 'Hello World')
    window.addControl(label)

    # Wait for the user to close the window
    xbmc.sleep(5000)
    window.close()
    del window

# If this script is executed directly, call the main function
if __name__ == '__main__':
    main()

