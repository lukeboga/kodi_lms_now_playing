import threading
from queue import Queue, Empty
from resources.lib.utils.log_message import log_message

class CallbackServer:
    def __init__(self):
        self.event_queue = Queue()
        self.callbacks = []
        self.running = True
        self.thread = threading.Thread(target=self.process_events)
        self.thread.daemon = True
        self.thread.start()

    def subscribe(self, callback):
        """
        Subscribe a callback to be executed when an event is received.
        Args:
            callback (function): The callback function to execute.
        """
        self.callbacks.append(callback)

    def add_event(self, event):
        """
        Add an event to the queue to be processed.
        Args:
            event (dict): The event data to be processed.
        """
        self.event_queue.put(event)

    def process_events(self):
        """
        Process events from the queue and execute subscribed callbacks.
        """
        while self.running:
            try:
                event = self.event_queue.get(timeout=1)
                for callback in self.callbacks:
                    callback(event)
            except Empty:
                continue

    def stop(self):
        """
        Stop the callback server and terminate the event processing thread.
        """
        self.running = False
        self.thread.join()
        log_message("Callback server stopped.")

