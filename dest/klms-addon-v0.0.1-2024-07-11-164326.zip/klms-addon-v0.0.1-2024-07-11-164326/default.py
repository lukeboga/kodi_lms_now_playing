# Import necessary modules from the Kodi API and the custom libraries
import xbmc
import xbmcplugin
import xbmcgui
import sys
from resources.lib.api.fetch_now_playing import get_now_playing
from resources.lib.api.log_now_playing import log_now_playing
from resources.lib.utils.log_message import log_message
from resources.lib.ui.now_playing_window import NowPlayingWindow

# Main entry point for the addon
def main():
    """
    The main function serves as the entry point for the addon.
    It parses arguments passed to the script, determines the action to take, and executes the appropriate function.
    """
    # Load the 'now playing' UI by default
    xbmcgui.WindowXML('nowplaying.xml', xbmcaddon.Addon().getAddonInfo('path'), 'default')

# Function to show the 'now playing' window
def show_now_playing():
    """
    Opens the custom window to display 'now playing' information.
    """
    now_playing = get_now_playing()
    window = NowPlayingWindow('nowplaying.xml', 'plugin.audio.klmsaddon', 'default', now_playing=now_playing)
    window.doModal()
    del window

# If this script is executed directly, call the main function
if __name__ == '__main__':
    main()

