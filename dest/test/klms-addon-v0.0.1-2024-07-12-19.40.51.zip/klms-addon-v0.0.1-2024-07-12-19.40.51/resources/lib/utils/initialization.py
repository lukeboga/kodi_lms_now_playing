import xbmc  # Kodi API module for logging
from resources.lib.utils.log_message import log_message
from resources.lib.api.fetch_now_playing import requests_session
from resources.lib.utils.read_settings import read_settings

def initialize():
    """
    Initialize the KLMS Addon.
    Load settings and establish necessary connections.
    """
    log_message("Initializing KLMS Addon...", xbmc.LOGINFO)
    settings = read_settings()
    # Add any other initialization steps here
    log_message("Initialization complete.", xbmc.LOGINFO)

def on_shutdown():
    """
    Handle the clean shutdown of the KLMS Addon.
    Close any open connections and clean up resources.
    """

    import gc  # Python garbage collection module
    import sys  # Ensure sys is imported within the function scope
    
    log_message("Shutting down KLMS Addon.", xbmc.LOGINFO)

    # Close the requests session
    if requests_session:
        requests_session.close()

    # Clear global variables
    for name in list(globals().keys()):
        if not name.startswith('__'):
            globals().pop(name)

    # Explicitly unload modules
    for module in ['requests', 'charset_normalizer']:
        if module in sys.modules:
            del sys.modules[module]

    # Force garbage collection
    gc.collect()

    log_message("Shutdown complete.", xbmc.LOGINFO)

